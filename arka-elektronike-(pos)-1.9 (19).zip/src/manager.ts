/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// This file acts as the public API for the 'manager' module.
export * from './manager/index';
