

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as dom from '../core/dom';
import * as state from '../core/state';
import * as storage from '../core/storage';
import { ReturnPurchaseInvoice, ReturnPurchaseInvoiceItem, Supplier, Product, Business, PurchaseInvoice, PurchaseInvoiceItem } from '../models';
import { generateUniqueId, getTodayDateString } from '../core/utils';
import * as uiUtils from '../core/ui'; 
import { setActiveManagerView } from './index';
import { createJournalEntryForPurchaseReturn } from './accountingUtils';

interface TempReturnItemUI {
    productId: string;
    productCode: string;
    productName: string;
    productUnitOfMeasure: string;
    originalQuantity: number;
    returnQuantity: number; 
    returnPriceWithoutVAT: number;
    vatRate: number;
    returnPriceWithVAT: number;
    totalReturnValueWithVAT: number;
}


let currentReturnPurchaseItems: TempReturnItemUI[] = [];
let currentEditingReturnPurchaseInvoiceId: string | null = null;
let originalPurchaseForReturnCache: PurchaseInvoice | null = null;
let selectedSupplierIdForReturnPurchase: string | null = null;


// --- Event Listeners and Initial Setup ---

export function initReturnPurchasesEventListeners(): void {
    const formContainer = dom.managerContentAddReturnPurchase;
    formContainer?.addEventListener('click', (event) => {
        const target = event.target as HTMLElement;
        if (target.matches('#save-return-purchase-btn')) {
            handleSaveReturnPurchase(event);
        } else if (target.matches('#cancel-return-purchase-form-btn')) {
            currentEditingReturnPurchaseInvoiceId = null;
            resetReturnPurchaseFormState();
            setActiveManagerView('return_purchases_list');
        }
    });
    formContainer?.querySelector('#return-purchase-form')?.addEventListener('submit', handleSaveReturnPurchase);
    formContainer?.querySelector('#rp-supplier-select')?.addEventListener('change', handleSupplierSelectionChange);
    formContainer?.querySelector('#rp-items-tbody')?.addEventListener('input', handleReturnTableItemInputChange);
    
    const listContainer = dom.returnPurchaseManagementPanel;
    listContainer?.addEventListener('click', (event) => {
        const target = event.target as HTMLElement;
        const viewButton = target.closest<HTMLButtonElement>('.view-rp-details-btn');
        const editButton = target.closest<HTMLButtonElement>('.edit-rp-btn');
        const deleteButton = target.closest<HTMLButtonElement>('.delete-rp-btn');

        if (viewButton) {
            const invoiceId = viewButton.dataset.invoiceId;
            if (invoiceId) openReturnPurchaseDetailsModal(invoiceId);
        } else if (editButton) {
            const invoiceId = editButton.dataset.invoiceId;
            if (invoiceId) {
                openReturnPurchaseFormModal(invoiceId);
                setActiveManagerView('add_return_purchase', `Modifiko Kthimin ${invoiceId}`);
            }
        } else if (deleteButton) {
            const invoiceId = deleteButton.dataset.invoiceId;
            const invoiceNumber = deleteButton.dataset.invoiceNumber;
            if (invoiceId && invoiceNumber) {
                handleDeleteReturnPurchaseInvoice(invoiceId, invoiceNumber);
            }
        }
    });

    dom.rpDetailsModalCloseBtn?.addEventListener('click', closeReturnPurchaseDetailsModal);
    dom.rpDetailsCloseModalActionBtn?.addEventListener('click', closeReturnPurchaseDetailsModal);
    dom.rpDetailsPrintInvoiceBtn?.addEventListener('click', handlePrintReturnPurchaseInvoice);
}

function resetReturnPurchaseFormState(): void {
    originalPurchaseForReturnCache = null;
    currentReturnPurchaseItems = [];
    selectedSupplierIdForReturnPurchase = null;
    if (dom.rpSupplierSelect) dom.rpSupplierSelect.value = '';
    const rpSupplierPurchasesListContainer = document.getElementById('rp-supplier-purchases-list-container') as HTMLDivElement | null;
    if (rpSupplierPurchasesListContainer) {
        rpSupplierPurchasesListContainer.innerHTML = '<p class="info-message secondary text-center">Zgjidhni një furnitor për të parë historikun e blerjeve.</p>';
        rpSupplierPurchasesListContainer.style.display = 'none';
    }
    const rpOriginalPurchaseDetails = document.getElementById('rp-original-purchase-details') as HTMLDivElement | null;
    if (rpOriginalPurchaseDetails) {
        rpOriginalPurchaseDetails.innerHTML = '';
        rpOriginalPurchaseDetails.style.display = 'none';
    }
    if (dom.rpItemsTbody) dom.rpItemsTbody.innerHTML = '<tr><td colspan="8" class="text-center">Zgjidhni një furnitor dhe pastaj një faturë blerjeje për të parë artikujt.</td></tr>';
    updateReturnTotals();
}

export function showReturnPurchaseManagementPanelFromManager(viewName: string, targetContainer?: HTMLElement): void {
    if (!targetContainer) {
        console.error("Target container not provided for Return Purchase panel.");
        return;
    }
    const panel = dom.returnPurchaseManagementPanel;
    if (panel) {
        if (!targetContainer.contains(panel)) {
            targetContainer.appendChild(panel);
        }
        panel.style.display = 'block';
        const tbody = panel.querySelector('#return-purchase-list-tbody');
        renderReturnPurchaseList(tbody as HTMLTableSectionElement);
        const addButton = panel.querySelector('#show-add-return-purchase-form-btn');
        addButton?.removeEventListener('click', openReturnPurchaseFormForNew);
        addButton?.addEventListener('click', openReturnPurchaseFormForNew);
    } else {
        targetContainer.innerHTML = '<p class="error-message">Paneli i menaxhimit të kthimeve të blerjeve nuk u gjet.</p>';
    }
}

function openReturnPurchaseFormForNew() {
    openReturnPurchaseFormModal();
    setActiveManagerView('add_return_purchase', 'Shto Kthim Blerjeje');
}

export function openReturnPurchaseFormModal(returnPurchaseIdToEdit?: string): void {
    const container = dom.managerContentAddReturnPurchase;
    if (!container) return;

    resetReturnPurchaseFormState();
    currentEditingReturnPurchaseInvoiceId = returnPurchaseIdToEdit || null;
    
    const formTitle = container.querySelector('#return-purchase-form-title') as HTMLHeadingElement;
    const form = container.querySelector('#return-purchase-form') as HTMLFormElement;
    const editIdInput = container.querySelector('#edit-return-purchase-id') as HTMLInputElement;
    const systemIdInput = container.querySelector('#rp-system-invoice-number') as HTMLInputElement;
    const supplierSelect = container.querySelector('#rp-supplier-select') as HTMLSelectElement;
    const returnDateInput = container.querySelector('#rp-invoice-date') as HTMLInputElement;
    const supplierInvoiceInput = container.querySelector('#rp-supplier-invoice-number') as HTMLInputElement;
    const reasonInput = container.querySelector('#rp-reason') as HTMLInputElement;
    
    if(!formTitle || !form || !editIdInput || !systemIdInput || !supplierSelect || !returnDateInput || !supplierInvoiceInput) return;
    
    form.reset();
    if(returnDateInput) returnDateInput.value = getTodayDateString();
    
    populateRPSupplierSelect();

    if(returnPurchaseIdToEdit) {
        // Edit logic would go here
    } else {
        formTitle.textContent = "Shto Kthim të Ri Blerjeje";
        const business = state.businesses.find(b => b.id === state.currentManagingBusinessId);
        const seed = business?.returnPurchaseInvoiceIdSeed || 1;
        const fiscalYear = business?.fiscalYear || new Date().getFullYear();
        systemIdInput.value = `KTHBL-${String(seed).padStart(3, '0')}-${fiscalYear}`;
    }
}

function renderReturnPurchaseList(tbodyElement: HTMLTableSectionElement | null): void {
    if (!tbodyElement || !state.currentManagingBusinessId) return;
    tbodyElement.innerHTML = '';
    const sortedInvoices = [...state.returnPurchaseInvoices].sort((a, b) => b.timestamp - a.timestamp);

    if (sortedInvoices.length === 0) {
        tbodyElement.innerHTML = '<tr><td colspan="6" class="text-center">Nuk ka kthime blerjesh të regjistruara.</td></tr>';
        return;
    }
    sortedInvoices.forEach(invoice => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${invoice.id}</td>
            <td>${invoice.supplierName}</td>
            <td>${invoice.supplierInvoiceNumber || '-'}</td>
            <td>${new Date(invoice.invoiceDate + 'T00:00:00').toLocaleDateString('sq-AL')}</td>
            <td class="text-right">${invoice.totalReturnAmountWithVAT.toFixed(2)} €</td>
            <td>
                <button class="btn btn-info btn-sm view-rp-details-btn" data-invoice-id="${invoice.id}">Detajet</button>
                <button class="btn btn-warning btn-sm edit-rp-btn" data-invoice-id="${invoice.id}" disabled>Modifiko</button>
                <button class="btn btn-danger btn-sm delete-rp-btn" data-invoice-id="${invoice.id}" data-invoice-number="${invoice.id}">Fshij</button>
            </td>
        `;
        tbodyElement.appendChild(tr);
    });
}

function populateRPSupplierSelect(): void {
    if (!dom.rpSupplierSelect) return;
    dom.rpSupplierSelect.innerHTML = '<option value="">-- Zgjidh Furnitorin --</option>';
    state.suppliers.forEach(supplier => {
        const option = document.createElement('option');
        option.value = supplier.id;
        option.textContent = `${supplier.name} (Kodi: ${supplier.code})`;
        dom.rpSupplierSelect?.appendChild(option);
    });
}

function handleSupplierSelectionChange() {
    // Logic to show original invoices for selected supplier
}

function displayPurchasesForSelectedSupplier(supplierId: string) {
    // Renders the list of original invoices
}

function displayOriginalPurchaseDetails() {
    // Shows details of the selected original purchase
}

function populateReturnItemsTableFromPurchase() {
    // Creates UI state for returnable items
}

function renderReturnItemsTable() {
    // Renders the table of items to be returned
}

function updateReturnTotals() {
    // Calculates and updates the summary totals
}

function handleReturnTableItemInputChange(event: Event) {
    // Handles quantity/price changes in the return items table
}

async function handleSaveReturnPurchase(event: Event) {
    event.preventDefault();
    if (!dom.returnPurchaseFormErrorElement || !state.currentUser || !state.currentManagingBusinessId || !originalPurchaseForReturnCache) {
        if(dom.returnPurchaseFormErrorElement) dom.returnPurchaseFormErrorElement.textContent = "Ju lutem plotësoni të gjitha fushat dhe zgjidhni një faturë blerjeje.";
        return;
    }

    const itemsToReturn = currentReturnPurchaseItems.filter(item => item.returnQuantity > 0);
    if (itemsToReturn.length === 0) {
        dom.returnPurchaseFormErrorElement.textContent = "Nuk keni zgjedhur asnjë artikull për kthim ose sasitë janë zero.";
        return;
    }
    
    const returnDate = dom.rpInvoiceDateInput?.value || getTodayDateString();
    const reason = dom.rpReasonInput?.value.trim() || undefined;
    const systemReturnInvoiceNumber = dom.rpSystemInvoiceNumberInput?.value;

    if(!systemReturnInvoiceNumber) {
        dom.returnPurchaseFormErrorElement.textContent = "Gabim: Mungon numri i sistemit për faturën e kthimit.";
        return;
    }

    const totalReturnAmountWithVAT = itemsToReturn.reduce((sum, item) => sum + (item.returnQuantity * item.returnPriceWithVAT), 0);
    const returnedInvoiceItems: ReturnPurchaseInvoiceItem[] = itemsToReturn.map(item => ({
        productId: item.productId,
        productCode: item.productCode,
        productName: item.productName,
        quantity: item.returnQuantity,
        returnPriceWithoutVAT: item.returnPriceWithoutVAT,
        vatRate: item.vatRate,
    }));
    
    const business = state.businesses.find(b => b.id === state.currentManagingBusinessId)!;
    const newReturnInvoice: ReturnPurchaseInvoice = {
        id: systemReturnInvoiceNumber,
        businessId: state.currentManagingBusinessId,
        supplierId: originalPurchaseForReturnCache.supplierId,
        supplierName: originalPurchaseForReturnCache.supplierName,
        supplierInvoiceNumber: originalPurchaseForReturnCache.supplierInvoiceNumber,
        invoiceDate: returnDate,
        items: returnedInvoiceItems,
        totalReturnAmountWithVAT: totalReturnAmountWithVAT,
        recordedByManagerId: state.currentUser.id,
        recordedByManagerUsername: state.currentUser.username,
        timestamp: Date.now()
    };
    
    state.returnPurchaseInvoices.push(newReturnInvoice);
    business.returnPurchaseInvoiceIdSeed = (business.returnPurchaseInvoiceIdSeed || 1) + 1;
    await storage.saveBusinessesToLocalStorage(state.businesses);
    await storage.saveReturnPurchaseInvoicesToLocalStorage(state.currentManagingBusinessId, state.returnPurchaseInvoices);
    
    // Adjust stock
    returnedInvoiceItems.forEach(item => {
        const product = state.products.find(p => p.id === item.productId);
        if (product) {
            product.stock -= item.quantity;
        }
    });
    await storage.saveProductsToLocalStorage(state.currentManagingBusinessId, state.products);

    // Create Journal Entry
    await createJournalEntryForPurchaseReturn(newReturnInvoice);

    uiUtils.showCustomConfirm(`Kthimi i blerjes ${systemReturnInvoiceNumber} u regjistrua me sukses. Stoku u përditësua.`, () => {
        resetReturnPurchaseFormState();
        setActiveManagerView('return_purchases_list');
    });
}

function handleDeleteReturnPurchaseInvoice(invoiceId: string, invoiceNumberForDisplay: string) {
    // Logic to delete a return purchase invoice and revert stock
}

function openReturnPurchaseDetailsModal(invoiceId: string) {
    // Logic to show the details modal
}

function closeReturnPurchaseDetailsModal(): void {
    if (dom.returnPurchaseDetailsModal) {
        dom.returnPurchaseDetailsModal.style.display = 'none';
        uiUtils.hidePageBlurOverlay();
    }
}

function handlePrintReturnPurchaseInvoice(event: Event) {
    // Logic to generate and print the return invoice
}