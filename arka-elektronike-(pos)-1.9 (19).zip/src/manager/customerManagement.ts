/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as dom from '../core/dom';
import * as state from '../core/state';
import * as storage from '../core/storage';
import { Customer } from '../models';
import { generateUniqueId } from '../core/utils';
import { showCustomConfirm } from '../core/ui';
import { populateSellerCustomerSelect } from '../seller';

export function initCustomerManagementEventListeners(): void {
    dom.showAddCustomerModalBtn?.addEventListener('click', () => openCustomerFormModal());
    dom.customerForm?.addEventListener('submit', handleSaveCustomer);
    dom.cancelCustomerFormBtn?.addEventListener('click', closeCustomerFormModal);
    if (dom.customerFormModalCloseBtn) dom.customerFormModalCloseBtn.addEventListener('click', closeCustomerFormModal);
}

export function showCustomerManagementPanelFromManager(viewName: string, targetContainer?: HTMLElement): void {
    if (!targetContainer) {
        console.error("Target container not provided for Customer Management panel.");
        return;
    }
    const panel = dom.customerManagementPanel;
    if (panel) {
        if (!targetContainer.contains(panel)) {
            targetContainer.appendChild(panel);
        }
        panel.style.display = 'block';
        renderCustomerListForManager();
    } else {
        targetContainer.innerHTML = '<p class="error-message">Paneli i menaxhimit të blerësve nuk u gjet.</p>';
    }
}

function generateCustomerCode(): string {
    const lastCustomerCode = state.customers
        .map(c => parseInt(c.code, 10))
        .filter(num => !isNaN(num))
        .sort((a, b) => b - a)[0]; 

    const nextCodeNumber = lastCustomerCode ? lastCustomerCode + 1 : 1;
    return nextCodeNumber.toString().padStart(3, '0'); 
}

export function openCustomerFormModal(customerId?: string): void {
    if (!dom.customerFormModal || !dom.customerForm || !dom.customerFormModalTitle || !dom.editCustomerIdInput ||
        !dom.customerFormCodeInput || !dom.customerFormNameInput || !dom.customerFormUniqueIdInput ||
        !dom.customerFormPhoneInput || !dom.customerFormEmailInput || !dom.customerFormAddressInput ||
        !dom.customerFormNotesInput || !dom.customerFormErrorElement) return;

    dom.customerForm.reset();
    dom.customerFormErrorElement.textContent = '';

    if (customerId) {
        const customer = state.customers.find(c => c.id === customerId);
        if (customer) {
            dom.customerFormModalTitle.textContent = "Modifiko Blerësin";
            dom.editCustomerIdInput.value = customer.id;
            dom.customerFormCodeInput.value = customer.code || '';
            dom.customerFormNameInput.value = customer.name;
            dom.customerFormUniqueIdInput.value = customer.uniqueId || '';
            dom.customerFormPhoneInput.value = customer.phone || '';
            dom.customerFormEmailInput.value = customer.email || '';
            dom.customerFormAddressInput.value = customer.address || '';
            dom.customerFormNotesInput.value = customer.notes || '';
        } else {
            dom.customerFormErrorElement.textContent = "Blerësi nuk u gjet.";
            return;
        }
    } else {
        dom.customerFormModalTitle.textContent = "Shto Blerës të Ri";
        dom.editCustomerIdInput.value = '';
        dom.customerFormCodeInput.value = generateCustomerCode();
    }
    dom.customerFormModal.style.display = 'block';
}

export function closeCustomerFormModal(): void {
    if (dom.customerFormModal) dom.customerFormModal.style.display = 'none';
}

export function handleSaveCustomer(event: Event): void {
    event.preventDefault();
    if (!dom.customerFormNameInput || !dom.customerFormErrorElement || !dom.editCustomerIdInput ||
        !state.currentManagingBusinessId || !dom.customerFormCodeInput || !dom.customerFormUniqueIdInput ||
        !dom.customerFormPhoneInput || !dom.customerFormEmailInput || !dom.customerFormAddressInput ||
        !dom.customerFormNotesInput) return;

    const name = dom.customerFormNameInput.value.trim();
    const code = dom.customerFormCodeInput.value.trim();
    const uniqueId = dom.customerFormUniqueIdInput.value.trim() || undefined;
    const phone = dom.customerFormPhoneInput.value.trim() || undefined;
    const email = dom.customerFormEmailInput.value.trim() || undefined;
    const address = dom.customerFormAddressInput.value.trim() || undefined;
    const notes = dom.customerFormNotesInput.value.trim() || undefined;
    const editingCustomerId = dom.editCustomerIdInput.value;
    dom.customerFormErrorElement.textContent = '';

    if (!name) {
        dom.customerFormErrorElement.textContent = "Emri i blerësit është i detyrueshëm.";
        return;
    }
    if (!code) {
        dom.customerFormErrorElement.textContent = "Kodi i blerësit mungon.";
        return;
    }

    const existingCustomerByCode = state.customers.find(c => c.code === code);
    if (existingCustomerByCode && existingCustomerByCode.id !== editingCustomerId) {
        dom.customerFormErrorElement.textContent = `Blerësi me kodin "${code}" ekziston tashmë. (${existingCustomerByCode.name})`;
        return;
    }
    
    if (editingCustomerId) {
        const customerToEdit = state.customers.find(c => c.id === editingCustomerId);
        if (customerToEdit) {
            customerToEdit.name = name;
            customerToEdit.code = code;
            customerToEdit.uniqueId = uniqueId;
            customerToEdit.phone = phone;
            customerToEdit.email = email;
            customerToEdit.address = address;
            customerToEdit.notes = notes;
        }
    } else {
        const newCustomer: Customer = {
            id: generateUniqueId('cust-'),
            businessId: state.currentManagingBusinessId,
            code: code,
            name: name,
            uniqueId: uniqueId,
            phone: phone,
            email: email,
            address: address,
            notes: notes,
        };
        state.customers.push(newCustomer);
    }

    storage.saveCustomersToLocalStorage(state.currentManagingBusinessId, state.customers);
    closeCustomerFormModal();
    renderCustomerListForManager();
    populateSellerCustomerSelect(); 
}

export function handleDeleteCustomer(customerId: string, customerName: string): void {
    if (!state.currentManagingBusinessId) return;

    showCustomConfirm(`Jeni i sigurt që doni të fshini blerësin "${customerName}"?`, () => {
        if (!state.currentManagingBusinessId) return;
        
        const business = state.businesses.find(b => b.id === state.currentManagingBusinessId);
        if (business && business.defaultCustomerId === customerId) {
            business.defaultCustomerId = undefined; 
            storage.saveBusinessesToLocalStorage(state.businesses); 
        }

        state.setCustomers(state.customers.filter(c => c.id !== customerId));
        storage.saveCustomersToLocalStorage(state.currentManagingBusinessId, state.customers);
        renderCustomerListForManager();
        populateSellerCustomerSelect(); 
        alert(`Blerësi "${customerName}" u fshi me sukses.`);
    });
}

export function handleSetDefaultCustomer(customerId: string) {
    if (!state.currentManagingBusinessId) return;
    const business = state.businesses.find(b => b.id === state.currentManagingBusinessId);
    if (business) {
        business.defaultCustomerId = customerId;
        storage.saveBusinessesToLocalStorage(state.businesses);
        renderCustomerListForManager(); 
        populateSellerCustomerSelect(); 
        alert(`Blerësi u caktua si default.`);
    }
}

export function renderCustomerListForManager(): void {
    if (!dom.customerListTbody || !state.currentManagingBusinessId) return;
    dom.customerListTbody.innerHTML = '';

    if (state.customers.length === 0) {
        dom.customerListTbody.innerHTML = '<tr><td colspan="3" class="text-center">Nuk ka blerës të regjistruar. Shtyp "Shto Blerës të Ri".</td></tr>';
        return;
    }
    
    const currentBusiness = state.businesses.find(b => b.id === state.currentManagingBusinessId);
    const defaultCustomerId = currentBusiness?.defaultCustomerId;

    state.customers.forEach(customer => {
        const tr = document.createElement('tr');
        const isDefault = customer.id === defaultCustomerId;
        tr.innerHTML = `
            <td>${customer.name} (Kodi: ${customer.code})</td>
            <td>${isDefault ? '<span class="status-badge default">Default</span>' : ''}</td>
            <td>
                <button class="btn btn-info btn-sm set-default-customer-btn" data-customer-id="${customer.id}" ${isDefault ? 'disabled' : ''}>Cakto Default</button>
                <button class="btn btn-warning btn-sm" data-customer-id="${customer.id}">Modifiko</button>
                <button class="btn btn-danger btn-sm" data-customer-id="${customer.id}" data-customer-name="${customer.name}">Fshij</button>
            </td>
        `;
        tr.querySelector<HTMLButtonElement>('.set-default-customer-btn')?.addEventListener('click', () => handleSetDefaultCustomer(customer.id));
        tr.querySelector<HTMLButtonElement>('.btn-warning')?.addEventListener('click', () => openCustomerFormModal(customer.id));
        tr.querySelector<HTMLButtonElement>('.btn-danger')?.addEventListener('click', () => handleDeleteCustomer(customer.id, customer.name));
        dom.customerListTbody.appendChild(tr);
    });
}