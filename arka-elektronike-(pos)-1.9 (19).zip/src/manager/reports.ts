/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as dom from '../core/dom';
import * as state from '../core/state';
import { getTodayDateString } from '../core/utils';
import { SaleRecord, PurchaseInvoice, BusinessDetails, LocalSaleInvoice, Account, JournalEntry, ReportTypeEnum, SalesReturnInvoice, CreditNote, DebitNote, Recipe, ProductionOrder, ReturnPurchaseInvoice, OutgoingPayment } from '../models'; 
import { generateReportHeaderHTML, generateReportFooterHTML, reportCategories, openPrintPreviewModal } from '../core/ui';

export type ReportType = `${ReportTypeEnum}`;
export type SetActiveManagerViewCallback = (viewName: string, title?: string, reportTypeContext?: ReportType) => void;

export interface ReportFilterConfig {
    id: string;
    label: string;
    type: 'DATE_RANGE' | 'SINGLE_DATE' | 'MONTH_YEAR' | 'SELECT';
    optionsSource?: 'sellers' | 'shifts' | 'months' | 'years' | 'customers' | 'categories' | 'products' | 'suppliers';
    defaultValue?: any;
    renderFunction: (id: string, label: string, defaultValue?: any, options?: { value: string, text: string }[]) => string;
}

export const reportConfigsData: Record<string, { title: string, categoryViewName: string, filters?: ReportFilterConfig[] }> = {
    [ReportTypeEnum.TrialBalance]: { 
        title: "Bilanci Provë", 
        categoryViewName: 'cat_accounting', 
        filters: [
            { id: 'trial_balance_date', label: 'Data e Raportit:', type: 'SINGLE_DATE', defaultValue: getTodayDateString(), renderFunction: (id, label, val) => `<div class="form-group filter-group"><label for="${id}">${label}</label><input type="date" id="${id}" value="${val || getTodayDateString()}" class="form-control"></div>` }
        ] 
    },
    [ReportTypeEnum.VatReport]: { 
        title: "Raporti i TVSH-së", 
        categoryViewName: 'cat_accounting', 
        filters: [
            { id: 'vat_report_date_range', label: 'Periudha:', type: 'DATE_RANGE', defaultValue: { start: getTodayDateString(), end: getTodayDateString() }, renderFunction: (id, label, val) => `<div class="form-group filter-group"><label for="${id}-start">Nga Data:</label><input type="date" id="${id}-start" value="${val?.start || getTodayDateString()}" class="form-control"><label for="${id}-end" style="margin-left:10px;">Deri më Datë:</label><input type="date" id="${id}-end" value="${val?.end || getTodayDateString()}" class="form-control"></div>` }
        ]
    },
    // Other report configurations would go here...
};

export function getReportConfig(reportType: ReportType) {
    return reportConfigsData[reportType];
}

export function setupReportViewStructure(reportType: ReportType, targetContainer: HTMLElement, setActiveCb: SetActiveManagerViewCallback) {
    const reportConfig = getReportConfig(reportType);
    if (!reportConfig) {
        targetContainer.innerHTML = `<p class="error-message">Konfigurimi për raportin '${reportType}' nuk u gjet.</p>`;
        return;
    }
    
    const templateContainer = dom.managerReportViewTemplate;
    if (!templateContainer) {
        targetContainer.innerHTML = `<p class="error-message">Struktura bazë e raportit (template) nuk u gjet.</p>`;
        return;
    }

    targetContainer.innerHTML = templateContainer.innerHTML;

    const titleElement = targetContainer.querySelector<HTMLHeadingElement>('.section-title');
    const filtersArea = targetContainer.querySelector<HTMLDivElement>('.report-filters-dynamic');
    const contentArea = targetContainer.querySelector<HTMLDivElement>('.report-content');
    const exportPdfBtn = targetContainer.querySelector<HTMLButtonElement>('.export-pdf-btn');
    const printBtn = targetContainer.querySelector<HTMLButtonElement>('.print-report-btn');
    const backBtn = targetContainer.querySelector<HTMLButtonElement>('.back-to-reports-btn');

    if (titleElement) titleElement.textContent = reportConfig.title;
    if (filtersArea) {
        filtersArea.innerHTML = '';
        if (reportConfig.filters && reportConfig.filters.length > 0) {
            reportConfig.filters.forEach(filter => {
                filtersArea.innerHTML += filter.renderFunction(filter.id, filter.label, filter.defaultValue);
            });
            const generateBtn = document.createElement('button');
            generateBtn.id = `dynamic-report-generate-btn-${reportType}`;
            generateBtn.className = 'btn btn-primary';
            generateBtn.textContent = 'Gjenero Raportin';
            filtersArea.appendChild(generateBtn);
            generateBtn.addEventListener('click', () => {
                generateAndDisplayReport(reportType, filtersArea, contentArea);
            });
        } else {
            filtersArea.style.display = 'none';
            generateAndDisplayReport(reportType, null, contentArea);
        }
    }

    backBtn?.addEventListener('click', () => setActiveCb(reportConfig.categoryViewName, undefined, undefined));
    exportPdfBtn?.addEventListener('click', () => console.log("Export PDF for", reportType));
    printBtn?.addEventListener('click', () => console.log("Print for", reportType));
}

function generateAndDisplayReport(reportType: ReportType, filtersArea: HTMLElement | null, contentArea: HTMLElement | null) {
    if (!contentArea) return;
    
    const getFilterValue = (id: string) => (filtersArea?.querySelector(`#${id}`) as HTMLInputElement)?.value || '';

    let reportHtml = `<p class="error-message">Raporti i kërkuar (${reportType}) nuk është implementuar ende.</p>`;
    
    switch (reportType) {
        case ReportTypeEnum.TrialBalance: {
            const date = getFilterValue('trial_balance_date');
            reportHtml = generateTrialBalanceHTML(date);
            break;
        }
        case ReportTypeEnum.VatReport: {
            const startDate = getFilterValue('vat_report_date_range-start');
            const endDate = getFilterValue('vat_report_date_range-end');
            reportHtml = generateVatReportHTML(startDate, endDate);
            break;
        }
    }
    contentArea.innerHTML = reportHtml;
}

function generateTrialBalanceHTML(asOfDate: string): string {
    const reportTitle = "BILANCI PROVË";
    const headerHtml = generateReportHeaderHTML(reportTitle, `Për Datën: ${new Date(asOfDate + 'T00:00:00').toLocaleDateString('sq-AL')}`);

    const balances = new Map<string, number>();
    const reportEndDate = new Date(asOfDate + "T23:59:59").getTime();

    state.accounts.forEach(acc => balances.set(acc.id, 0));
    state.journalEntries
        .filter(entry => new Date(entry.date + "T00:00:00").getTime() <= reportEndDate)
        .forEach(entry => {
            entry.lines.forEach(line => {
                const currentBalance = balances.get(line.accountId) || 0;
                balances.set(line.accountId, currentBalance + line.debit - line.credit);
            });
        });

    let tableRowsHtml = '';
    let totalDebit = 0;
    let totalCredit = 0;

    state.accounts.sort((a,b) => a.accountNumber.localeCompare(b.accountNumber)).forEach(account => {
        const balance = balances.get(account.id) || 0;
        let debit = 0;
        let credit = 0;

        if (['Asset', 'Expense'].includes(account.type)) {
            if (balance > 0) debit = balance;
            else credit = -balance;
        } else { // Liability, Equity, Revenue
            if (balance < 0) debit = -balance;
            else credit = balance;
        }
        
        if (debit > 0 || credit > 0) {
            tableRowsHtml += `
                <tr>
                    <td>${account.accountNumber}</td>
                    <td>${account.name}</td>
                    <td class="text-right">${debit > 0 ? debit.toFixed(2) : '-'}</td>
                    <td class="text-right">${credit > 0 ? credit.toFixed(2) : '-'}</td>
                </tr>
            `;
            totalDebit += debit;
            totalCredit += credit;
        }
    });

    const isBalanced = Math.abs(totalDebit - totalCredit) < 0.01;

    const tableHtml = `
        <div class="report-table-container">
            <table class="admin-table">
                <thead><tr><th>Nr. Llogarisë</th><th>Emri i Llogarisë</th><th class="text-right">Debi (€)</th><th class="text-right">Kredi (€)</th></tr></thead>
                <tbody>${tableRowsHtml}</tbody>
                <tfoot>
                    <tr class="grand-total-row">
                        <td colspan="2" class="text-right"><strong>TOTALET:</strong></td>
                        <td class="text-right"><strong>${totalDebit.toFixed(2)} €</strong></td>
                        <td class="text-right"><strong>${totalCredit.toFixed(2)} €</strong></td>
                    </tr>
                    <tr>
                        <td colspan="4" class="text-center strong ${isBalanced ? 'cash-value positive' : 'cash-value negative'}">
                            ${isBalanced ? '✔ I BALANCUAR' : '✖ I PA BALANCUAR'}
                        </td>
                    </tr>
                </tfoot>
            </table>
        </div>`;
    
    return `<div class="printable-area">${headerHtml}${tableHtml}${generateReportFooterHTML()}</div>`;
}

function generateVatReportHTML(startDateStr: string, endDateStr: string): string {
    const reportTitle = "RAPORTI I TVSH-SË";
    const period = `${new Date(startDateStr + "T00:00:00").toLocaleDateString('sq-AL')} - ${new Date(endDateStr + "T23:59:59").toLocaleDateString('sq-AL')}`;
    const headerHtml = generateReportHeaderHTML(reportTitle, `Periudha: ${period}`);
    
    const startTs = new Date(startDateStr + "T00:00:00").getTime();
    const endTs = new Date(endDateStr + "T23:59:59").getTime();

    // TVSH e Mbledhur (nga Shitjet)
    const sales = [...state.salesLog, ...state.localSalesInvoices]
        .filter(sale => sale.timestamp >= startTs && sale.timestamp <= endTs);
    let totalVatCollected = 0;
    let totalSalesValue = 0;
    sales.forEach(sale => {
        const totalWithVAT = 'grandTotal' in sale ? sale.grandTotal : sale.totalAmountWithVAT;
        const totalWithoutVAT = 'subtotal' in sale ? sale.subtotal : sale.totalAmountWithoutVAT;
        totalVatCollected += (totalWithVAT - totalWithoutVAT);
        totalSalesValue += totalWithoutVAT;
    });

    // TVSH e Zbritshme (nga Blerjet)
    const purchases = state.purchaseInvoices
        .filter(inv => inv.timestamp >= startTs && inv.timestamp <= endTs);
    let totalVatDeductible = 0;
    let totalPurchasesValue = 0;
    purchases.forEach(inv => {
        totalVatDeductible += inv.totalVATAmount;
        totalPurchasesValue += inv.totalAmountWithoutVAT;
    });
    
    const vatLiability = totalVatCollected - totalVatDeductible;

    const reportContent = `
        <div class="report-table-container" style="margin-bottom: 2rem;">
            <h3 class="section-subtitle">TVSH e Mbledhur (nga Shitjet)</h3>
            <table class="admin-table">
                <tbody>
                    <tr><td>Vlera e Shitjeve pa TVSH</td><td class="text-right">${totalSalesValue.toFixed(2)} €</td></tr>
                    <tr><td>TVSH e Mbledhur</td><td class="text-right">${totalVatCollected.toFixed(2)} €</td></tr>
                </tbody>
            </table>
        </div>
        <div class="report-table-container">
            <h3 class="section-subtitle">TVSH e Zbritshme (nga Blerjet)</h3>
            <table class="admin-table">
                <tbody>
                    <tr><td>Vlera e Blerjeve pa TVSH</td><td class="text-right">${totalPurchasesValue.toFixed(2)} €</td></tr>
                    <tr><td>TVSH e Zbritshme</td><td class="text-right">${totalVatDeductible.toFixed(2)} €</td></tr>
                </tbody>
            </table>
        </div>
        <div class="report-summary" style="margin-top: 2rem; padding: 1rem; text-align: center;">
             <p style="font-size: 1.2rem;"><strong>DETYRIMI / KREDIA E TVSH-së: <span class="${vatLiability >= 0 ? 'cash-value' : 'cash-value positive'}">${vatLiability.toFixed(2)} €</span></strong></p>
             <p class="info-message secondary" style="font-size: 0.9em; text-align: left;">Shënim: Vlera pozitive tregon detyrim për pagesë. Vlera negative tregon TVSH të tepërt për kreditim/rimbursim.</p>
        </div>
    `;

    return `<div class="printable-area">${headerHtml}${reportContent}${generateReportFooterHTML()}</div>`;
}

export function renderReportCategoryTiles(activeViewName: string, targetContainer: HTMLElement | undefined, setActiveCb: SetActiveManagerViewCallback) {
    if (!activeViewName || !targetContainer) {
        console.warn("renderReportCategoryTiles called with invalid arguments.");
        return;
    }

    const categoryConfig = reportCategories.find(rc => rc.id === activeViewName);
    if (!categoryConfig) {
        console.warn(`No report category config found for view: ${activeViewName}`);
        targetContainer.innerHTML = `<p class="error-message">Konfigurimi i kategorisë së raportit '${activeViewName}' nuk u gjet.</p>`;
        return;
    }
    
    let viewTitle = 'Raporte';
    const menuItem = state.managerMenuConfig.flatMap(cat => cat.items).find(item => item.dataView === activeViewName);
    if (menuItem) viewTitle = menuItem.name;

    targetContainer.innerHTML = ''; 

    const titleElement = document.createElement('h2');
    titleElement.className = 'manager-section-title';
    titleElement.textContent = viewTitle;
    targetContainer.appendChild(titleElement);

    const tileGrid = document.createElement('div');
    tileGrid.id = categoryConfig.containerId;
    tileGrid.className = 'report-category-tiles-grid';
    targetContainer.appendChild(tileGrid);

    if (categoryConfig.reports.length === 0) {
        tileGrid.innerHTML = '<p class="info-message">Nuk ka raporte të definuara për këtë kategori.</p>';
        return;
    }

    categoryConfig.reports.forEach(report => {
        const reportButton = document.createElement('button');
        reportButton.className = 'report-action-button';
        reportButton.dataset.reportType = report.type;
        reportButton.textContent = report.name;
        reportButton.setAttribute('aria-label', `Gjenero ${report.name}`);

        reportButton.addEventListener('click', () => {
            setActiveCb(report.type, report.name, report.type as ReportType);
        });
        tileGrid.appendChild(reportButton);
    });
}

// --- Printable HTML Generators ---

export function generatePrintableSalesReportHTML(
    sales: SaleRecord[], 
    reportDate: string, 
    reportTitle: string = "Raport Shitjesh",
    context?: 'todaysSales'
): string {
    const businessDetails = state.businessDetails;
    let grandTotal = 0;
    
    const salesHtml = sales.map(sale => {
        grandTotal += sale.grandTotal;
        const customer = state.customers.find(c => c.id === sale.customerId);
        let itemsHtml = '';
        sale.items.forEach(item => {
            itemsHtml += `
                <tr>
                    <td>${item.name} ${item.isDeal ? '(Ofertë)' : ''}</td>
                    <td class="text-right">${item.quantity}</td>
                    <td class="text-right">${item.price.toFixed(2)}</td>
                    <td class="text-right">${(item.quantity * item.price).toFixed(2)}</td>
                </tr>
            `;
        });
        
        const customerInfo = customer 
            ? `<p><strong>Blerësi:</strong> ${customer.name}</p>${customer.address ? `<p>Adresa: ${customer.address}</p>` : ''}${customer.uniqueId ? `<p>NIPT/ID: ${customer.uniqueId}</p>` : ''}`
            : `<p><strong>Blerësi:</strong> ${sale.customerName || 'Klient Standard'}</p>`;
            
        return `
            <div class="invoice-container">
                <div class="invoice-header-print">
                    ${businessDetails?.logoUrl ? `<div class="invoice-logo"><img src="${businessDetails.logoUrl}" alt="Logo e Biznesit"></div>` : ''}
                    <div class="invoice-business-details">
                        <h2>${businessDetails?.name || ''}</h2>
                        <p>${businessDetails?.address || ''}</p>
                        <p>NIPT: ${businessDetails?.nipt || ''}</p>
                    </div>
                    <div class="invoice-meta">
                        <h1>${context === 'todaysSales' ? 'FATURË' : reportTitle}</h1>
                        <p>Nr. Faturës: <strong>${sale.invoiceNumber}</strong></p>
                        <p>Data: <strong>${new Date(sale.timestamp).toLocaleString('sq-AL')}</strong></p>
                    </div>
                </div>
                <div class="invoice-parties">
                    <div class="invoice-seller-details">
                        <h3>Shitësi:</h3>
                        <p>${sale.sellerUsername}</p>
                    </div>
                    <div class="invoice-buyer-details">
                        ${customerInfo}
                    </div>
                </div>
                <table class="invoice-items-table">
                    <thead>
                        <tr>
                            <th>Artikulli</th>
                            <th class="text-right">Sasia</th>
                            <th class="text-right">Çmimi (€)</th>
                            <th class="text-right">Vlera (€)</th>
                        </tr>
                    </thead>
                    <tbody>${itemsHtml}</tbody>
                    <tfoot>
                        <tr class="grand-total-row">
                            <td colspan="3" class="text-right"><strong>TOTALI:</strong></td>
                            <td class="text-right"><strong>${sale.grandTotal.toFixed(2)} €</strong></td>
                        </tr>
                        ${sale.amountReceived ? `<tr><td colspan="3" class="text-right">Paguara:</td><td class="text-right">${sale.amountReceived.toFixed(2)} €</td></tr>` : ''}
                        ${sale.changeGiven ? `<tr><td colspan="3" class="text-right">Kusuri:</td><td class="text-right">${sale.changeGiven.toFixed(2)} €</td></tr>` : ''}
                    </tfoot>
                </table>
                <div class="invoice-thank-you-message">
                    <p>Faleminderit për blerjen!</p>
                    <p>Ky dokument është gjeneruar nga sistemi ${state.superAdminAppSettings?.mainAppName || 'Arka Elektronike'}.</p>
                </div>
            </div>
            ${sales.length > 1 ? '<div class="page-break"></div>' : ''}
        `;
    }).join('');

    const summaryHtml = sales.length > 1 ? `
        <div class="report-summary" style="margin-top: 2rem;">
            <h2>Përmbledhje e Raportit</h2>
            <p><strong>Data e Raportit:</strong> ${reportDate}</p>
            <p><strong>Numri i Faturave:</strong> ${sales.length}</p>
            <p><strong>Shuma Totale:</strong> ${grandTotal.toFixed(2)} €</p>
        </div>
    ` : '';

    return `<div class="printable-area">${summaryHtml}${salesHtml}</div>`;
}

export function generatePrintablePurchaseInvoiceHTML(invoice: PurchaseInvoice, businessDetails?: BusinessDetails | null): string {
    const businessName = businessDetails?.name || "Emri i Biznesit";
    const businessAddress = businessDetails?.address || "";
    const businessNipt = businessDetails?.nipt || "";
    const logoUrl = businessDetails?.logoUrl;
    let logoHtml = logoUrl ? `<div class="invoice-logo"><img src="${logoUrl}" alt="Logo e Biznesit"></div>` : '';

    const itemsHtml = invoice.items.map((item, index) => `
        <tr>
            <td>${index + 1}</td>
            <td>${item.productCode}</td>
            <td>${item.productName}</td>
            <td class="text-right">${item.quantity} ${item.productUnitOfMeasure}</td>
            <td class="text-right">${item.purchasePriceWithoutVAT.toFixed(2)}</td>
            <td class="text-right">${item.vatRate.toFixed(2)}%</td>
            <td class="text-right">${item.totalValueWithoutVAT.toFixed(2)}</td>
            <td class="text-right">${item.totalValueWithVAT.toFixed(2)}</td>
        </tr>
    `).join('');

    return `
        <div class="printable-invoice-area">
            ${generateReportHeaderHTML('FATURË BLERJE', `Data: ${new Date(invoice.invoiceDate + 'T00:00:00').toLocaleDateString('sq-AL')}`)}
            <div class="invoice-parties">
                <div class="invoice-supplier-details" style="width: 100%;">
                    <h3>Furnitori:</h3>
                    <p><strong>${invoice.supplierName}</strong></p>
                    <p>Nr. Sistemi: <strong>${invoice.id}</strong></p>
                    <p>Nr. Furnitori: <strong>${invoice.supplierInvoiceNumber}</strong></p>
                </div>
            </div>
            <table class="invoice-items-table">
                <thead>
                    <tr>
                        <th>Nr.</th>
                        <th>Kodi</th>
                        <th>Artikulli</th>
                        <th class="text-right">Sasia</th>
                        <th class="text-right">Çmimi (pa TVSH)</th>
                        <th class="text-right">TVSH</th>
                        <th class="text-right">Vlera (pa TVSH)</th>
                        <th class="text-right">Vlera (me TVSH)</th>
                    </tr>
                </thead>
                <tbody>${itemsHtml}</tbody>
                <tfoot>
                    <tr><td colspan="7" class="text-right">Nëntotali (pa TVSH):</td><td class="text-right">${invoice.totalAmountWithoutVAT.toFixed(2)} €</td></tr>
                    <tr><td colspan="7" class="text-right">Vlera e TVSH-së:</td><td class="text-right">${invoice.totalVATAmount.toFixed(2)} €</td></tr>
                    <tr class="grand-total-row"><td colspan="7" class="text-right"><strong>TOTALI (me TVSH):</strong></td><td class="text-right"><strong>${invoice.totalAmountWithVAT.toFixed(2)} €</strong></td></tr>
                </tfoot>
            </table>
            ${generateReportFooterHTML()}
        </div>
    `;
}
export function generatePrintableReturnPurchaseInvoiceHTML(invoice: ReturnPurchaseInvoice, businessDetails?: BusinessDetails | null): string { 
    return `<p>Printim Kthim Blerje ${invoice.id}</p>`; 
}
export function generatePrintableOutgoingPaymentHTML(payment: OutgoingPayment, businessDetails?: BusinessDetails | null): string { 
    return `<p>Printim Pagese Dalëse ${payment.id}</p>`; 
}
export function generatePrintableSalesReturnInvoiceHTML(invoice: SalesReturnInvoice, businessDetails?: BusinessDetails | null): string { 
    return `<p>Printim Kthim Shitje ${invoice.id}</p>`; 
}
export function generatePrintableLocalSaleInvoiceHTML(invoice: LocalSaleInvoice, businessDetails?: BusinessDetails | null): string { 
    return `<p>Printim Shitje Lokale ${invoice.id}</p>`; 
}