/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// This file simulates a backend API client.
// It uses localStorage for persistence, falling back to db.json for initial data.

import * as state from './state';
import * as config from './config';
import { 
    User, Product, Category, ItemType, DailyCashEntry, SaleRecord, 
    ClearedSaleLogEntry, BusinessDetails, Deal, Customer, Supplier, 
    PurchaseInvoice, ReturnPurchaseInvoice, SalesReturnInvoice, OutgoingPayment, 
    IncomingPayment, LocalSaleInvoice, CreditNote, DebitNote, Recipe, 
    ProductionOrder, ProductionStage, ProductionRouting, SubscriptionPackage, 
    MenuCategoryConfig, Business, Employee, TimeLog, LeaveRequest, Overtime, PayrollEntry,
    Group, Privilege, GroupPrivilege, Account, JournalEntry, AccountingSettings
} from '../models';
import { simpleHash } from './utils';

// --- Caching for db.json ---
let dbData: any = null;
let dbLoadPromise: Promise<any> | null = null;

async function getDbData(): Promise<any> {
    if (dbData) {
        return dbData;
    }
    if (dbLoadPromise) {
        return dbLoadPromise;
    }

    dbLoadPromise = new Promise(async (resolve) => {
        try {
            const response = await fetch('/db.json');
            if (!response.ok) {
                throw new Error(`Failed to fetch db.json: ${response.statusText}`);
            }
            const data = await response.json();
            dbData = data;
            resolve(data);
        } catch (error) {
            console.error("Could not load or parse db.json. Application may not function correctly with pre-seeded data.", error);
            dbData = {}; 
            resolve(dbData);
        } finally {
            dbLoadPromise = null;
        }
    });

    return dbLoadPromise;
}


// --- Helper Functions ---

export function getBusinessStorageKey(baseKey: string, businessId: string): string {
    if (!businessId) {
        console.error(`Attempted to get storage key for base '${baseKey}' without a businessId.`);
        return `${baseKey}_unknown_business`;
    }
    return `${config.BUSINESS_DATA_PREFIX}${businessId}_${baseKey}`;
}

async function getBusinessData<T>(businessId: string, baseKey: string, dbKey: string): Promise<T[]> {
    const key = getBusinessStorageKey(baseKey, businessId);
    const storedData = localStorage.getItem(key);
    if (storedData) {
        try { return JSON.parse(storedData) as T[]; }
        catch (e) { console.error(`Failed to parse localStorage data for key ${key}`, e); }
    }
    const db = await getDbData();
    const initialData = db?.[dbKey]?.filter((item: any) => item.businessId === businessId) || [];
    localStorage.setItem(key, JSON.stringify(initialData));
    return initialData;
}

async function saveBusinessData<T>(businessId: string, baseKey: string, data: T[]): Promise<void> {
    const key = getBusinessStorageKey(baseKey, businessId);
    localStorage.setItem(key, JSON.stringify(data));
}

async function getGlobalData<T>(storageKey: string, dbKey: string, defaultValue: T): Promise<T> {
    const storedData = localStorage.getItem(storageKey);
    if (storedData) {
        try { return JSON.parse(storedData); }
        catch(e) { console.error(`Failed to parse localStorage data for key ${storageKey}`, e); }
    }
    const db = await getDbData();
    const initialData = db?.[dbKey] || defaultValue;
    localStorage.setItem(storageKey, JSON.stringify(initialData));
    return initialData;
}

async function saveGlobalData<T>(storageKey: string, data: T): Promise<void> {
    localStorage.setItem(storageKey, JSON.stringify(data));
}


// --- API Functions ---

// Super Admin & General Config
export async function getSuperAdminPasswordHash(): Promise<string | null> {
    return getGlobalData<string | null>(config.SUPER_ADMIN_PASSWORD_STORAGE_KEY, 'superAdminPasswordHash', null);
}
export async function saveSuperAdminPasswordHash(hash: string): Promise<void> {
    await saveGlobalData(config.SUPER_ADMIN_PASSWORD_STORAGE_KEY, hash);
}

export async function getSuperAdminAppSettings(): Promise<any> {
    return getGlobalData<any>(config.SUPER_ADMIN_APP_SETTINGS_STORAGE_KEY, 'appSettings', {});
}
export async function saveSuperAdminAppSettings(settings: any): Promise<void> {
    await saveGlobalData(config.SUPER_ADMIN_APP_SETTINGS_STORAGE_KEY, settings);
}

export async function getAllBusinesses(): Promise<Business[]> {
    return getGlobalData<Business[]>(config.ALL_BUSINESSES_STORAGE_KEY, 'businesses', []);
}
export async function saveAllBusinesses(businesses: Business[]): Promise<void> {
    await saveGlobalData(config.ALL_BUSINESSES_STORAGE_KEY, businesses);
}
export const saveBusinessesToLocalStorage = saveAllBusinesses;

export async function getSubscriptionPackages(): Promise<SubscriptionPackage[]> {
    return getGlobalData<SubscriptionPackage[]>(config.SUPER_ADMIN_SUBSCRIPTION_PACKAGES_KEY, 'subscriptionPackages', []);
}
export async function saveSubscriptionPackages(packages: SubscriptionPackage[]): Promise<void> {
    await saveGlobalData(config.SUPER_ADMIN_SUBSCRIPTION_PACKAGES_KEY, packages);
}

export async function getManagerMenuConfig(): Promise<MenuCategoryConfig[]> {
    return getGlobalData<MenuCategoryConfig[]>(config.MANAGER_MENU_CONFIG_STORAGE_KEY, 'managerMenuConfig', []);
}
export async function saveManagerMenuConfig(menuConfig: MenuCategoryConfig[]): Promise<void> {
    await saveGlobalData(config.MANAGER_MENU_CONFIG_STORAGE_KEY, menuConfig);
}

// Business Specific Data
export async function getUsers(businessId: string): Promise<User[]> { return getBusinessData(businessId, config.BASE_USERS_STORAGE_KEY, 'users'); }
export async function saveUsers(businessId: string, users: User[]): Promise<void> { await saveBusinessData(businessId, config.BASE_USERS_STORAGE_KEY, users); }

export async function getGroups(businessId: string): Promise<Group[]> { return getBusinessData(businessId, config.BASE_GROUPS_STORAGE_KEY, 'groups'); }
export async function saveGroups(businessId: string, groups: Group[]): Promise<void> { await saveBusinessData(businessId, config.BASE_GROUPS_STORAGE_KEY, groups); }

export async function getPrivileges(): Promise<Privilege[]> { return getGlobalData(config.BASE_PRIVILEGES_STORAGE_KEY, 'privileges', []); }

export async function getGroupPrivileges(businessId: string): Promise<GroupPrivilege[]> { return getBusinessData(businessId, config.BASE_GROUP_PRIVILEGES_STORAGE_KEY, 'groupPrivileges'); }
export async function saveGroupPrivileges(businessId: string, groupPrivileges: GroupPrivilege[]): Promise<void> { await saveBusinessData(businessId, config.BASE_GROUP_PRIVILEGES_STORAGE_KEY, groupPrivileges); }

export async function getEmployees(businessId: string): Promise<Employee[]> { return getBusinessData(businessId, config.BASE_EMPLOYEES_STORAGE_KEY, 'employees'); }
export async function saveEmployees(businessId: string, employees: Employee[]): Promise<void> { await saveBusinessData(businessId, config.BASE_EMPLOYEES_STORAGE_KEY, employees); }

export async function getTimeLogs(businessId: string): Promise<TimeLog[]> { return getBusinessData(businessId, config.BASE_TIME_LOGS_STORAGE_KEY, 'timeLogs'); }
export async function saveTimeLogs(businessId: string, timeLogs: TimeLog[]): Promise<void> { await saveBusinessData(businessId, config.BASE_TIME_LOGS_STORAGE_KEY, timeLogs); }

export async function getLeaveRequests(businessId: string): Promise<LeaveRequest[]> { return getBusinessData(businessId, config.BASE_LEAVE_REQUESTS_STORAGE_KEY, 'leaveRequests'); }
export async function saveLeaveRequests(businessId: string, leaveRequests: LeaveRequest[]): Promise<void> { await saveBusinessData(businessId, config.BASE_LEAVE_REQUESTS_STORAGE_KEY, leaveRequests); }

export async function getOvertimeEntries(businessId: string): Promise<Overtime[]> { return getBusinessData(businessId, config.BASE_OVERTIME_ENTRIES_STORAGE_KEY, 'overtimeEntries'); }
export async function saveOvertimeEntries(businessId: string, overtimeEntries: Overtime[]): Promise<void> { await saveBusinessData(businessId, config.BASE_OVERTIME_ENTRIES_STORAGE_KEY, overtimeEntries); }

export async function getPayrollEntries(businessId: string): Promise<PayrollEntry[]> { return getBusinessData(businessId, config.BASE_PAYROLL_ENTRIES_STORAGE_KEY, 'payrollEntries'); }
export async function savePayrollEntries(businessId: string, payrollEntries: PayrollEntry[]): Promise<void> { await saveBusinessData(businessId, config.BASE_PAYROLL_ENTRIES_STORAGE_KEY, payrollEntries); }

export async function getProducts(businessId: string): Promise<Product[]> { return getBusinessData(businessId, config.BASE_PRODUCTS_STORAGE_KEY, 'products'); }
export async function saveProducts(businessId: string, products: Product[]): Promise<void> { await saveBusinessData(businessId, config.BASE_PRODUCTS_STORAGE_KEY, products); }

export async function getDailyCashLog(businessId: string): Promise<DailyCashEntry[]> { return getBusinessData(businessId, config.BASE_DAILY_CASH_LOG_KEY, 'dailyCashLog'); }
export async function saveDailyCashLog(businessId: string, log: DailyCashEntry[]): Promise<void> { await saveBusinessData(businessId, config.BASE_DAILY_CASH_LOG_KEY, log); }

export async function getSalesLog(businessId: string): Promise<SaleRecord[]> { return getBusinessData(businessId, config.BASE_SALES_LOG_STORAGE_KEY, 'salesLog'); }
export async function saveSalesLog(businessId: string, log: SaleRecord[]): Promise<void> { await saveBusinessData(businessId, config.BASE_SALES_LOG_STORAGE_KEY, log); }

export async function getClearedSalesLog(businessId: string): Promise<ClearedSaleLogEntry[]> { return getBusinessData(businessId, config.BASE_CLEARED_SALES_LOG_KEY, 'clearedSalesLog'); }
export async function saveClearedSalesLog(businessId: string, log: ClearedSaleLogEntry[]): Promise<void> { await saveBusinessData(businessId, config.BASE_CLEARED_SALES_LOG_KEY, log); }

export async function getBusinessDetails(businessId: string): Promise<BusinessDetails | null> {
    const key = getBusinessStorageKey(config.BASE_BUSINESS_DETAILS_STORAGE_KEY, businessId);
    const storedData = localStorage.getItem(key);
    if (storedData) {
        try { return JSON.parse(storedData); } catch (e) { console.error(e); }
    }
    const db = await getDbData();
    const initialData = db?.businessDetails?.find((d: any) => d.businessId === businessId) || null;
    if(initialData) localStorage.setItem(key, JSON.stringify(initialData));
    return initialData;
}
export async function saveBusinessDetails(businessId: string, details: BusinessDetails): Promise<void> {
    const key = getBusinessStorageKey(config.BASE_BUSINESS_DETAILS_STORAGE_KEY, businessId);
    localStorage.setItem(key, JSON.stringify(details));
}

export async function getClearSalePinHash(businessId: string): Promise<string> {
    const key = getBusinessStorageKey(config.BASE_CLEAR_SALE_PIN_HASH_STORAGE_KEY, businessId);
    const storedData = localStorage.getItem(key);
    return storedData || simpleHash(config.DEFAULT_CLEAR_SALE_PIN);
}
export async function saveClearSalePinHash(businessId: string, pin: string): Promise<void> {
    const key = getBusinessStorageKey(config.BASE_CLEAR_SALE_PIN_HASH_STORAGE_KEY, businessId);
    localStorage.setItem(key, simpleHash(pin));
}

export async function getDeals(businessId: string): Promise<Deal[]> { return getBusinessData(businessId, config.BASE_DEALS_STORAGE_KEY, 'deals'); }
export async function saveDeals(businessId: string, deals: Deal[]): Promise<void> { await saveBusinessData(businessId, config.BASE_DEALS_STORAGE_KEY, deals); }

export async function getCustomers(businessId: string): Promise<Customer[]> { return getBusinessData(businessId, config.BASE_CUSTOMERS_STORAGE_KEY, 'customers'); }
export async function saveCustomers(businessId: string, customers: Customer[]): Promise<void> { await saveBusinessData(businessId, config.BASE_CUSTOMERS_STORAGE_KEY, customers); }

export async function getCategories(businessId: string): Promise<Category[]> { return getBusinessData(businessId, config.BASE_CATEGORIES_STORAGE_KEY, 'categories'); }
export async function saveCategories(businessId: string, categories: Category[]): Promise<void> { await saveBusinessData(businessId, config.BASE_CATEGORIES_STORAGE_KEY, categories); }

export async function getItemTypes(businessId: string): Promise<ItemType[]> { return getBusinessData(businessId, config.BASE_ITEM_TYPES_STORAGE_KEY, 'itemTypes'); }
export async function saveItemTypes(businessId: string, itemTypes: ItemType[]): Promise<void> { await saveBusinessData(businessId, config.BASE_ITEM_TYPES_STORAGE_KEY, itemTypes); }

export async function getSuppliers(businessId: string): Promise<Supplier[]> { return getBusinessData(businessId, config.BASE_SUPPLIERS_STORAGE_KEY, 'suppliers'); }
export async function saveSuppliers(businessId: string, suppliers: Supplier[]): Promise<void> { await saveBusinessData(businessId, config.BASE_SUPPLIERS_STORAGE_KEY, suppliers); }

export async function getAccounts(businessId: string): Promise<Account[]> { return getBusinessData(businessId, config.BASE_ACCOUNTS_STORAGE_KEY, 'accounts'); }
export async function saveAccounts(businessId: string, accounts: Account[]): Promise<void> { await saveBusinessData(businessId, config.BASE_ACCOUNTS_STORAGE_KEY, accounts); }

export async function getJournalEntries(businessId: string): Promise<JournalEntry[]> { return getBusinessData(businessId, config.BASE_JOURNAL_ENTRIES_STORAGE_KEY, 'journalEntries'); }
export async function saveJournalEntries(businessId: string, entries: JournalEntry[]): Promise<void> { await saveBusinessData(businessId, config.BASE_JOURNAL_ENTRIES_STORAGE_KEY, entries); }

export async function getAccountingSettings(businessId: string): Promise<AccountingSettings | null> {
    const key = getBusinessStorageKey(config.BASE_ACCOUNTING_SETTINGS_STORAGE_KEY, businessId);
    const storedData = localStorage.getItem(key);
    if (storedData) {
        try { return JSON.parse(storedData); } catch (e) { console.error(e); }
    }
    const db = await getDbData();
    const initialData = db?.accountingSettings?.find((s: any) => s.businessId === businessId) || null;
    if(initialData) localStorage.setItem(key, JSON.stringify(initialData));
    return initialData;
}
export async function saveAccountingSettings(businessId: string, settings: AccountingSettings): Promise<void> {
    const key = getBusinessStorageKey(config.BASE_ACCOUNTING_SETTINGS_STORAGE_KEY, businessId);
    localStorage.setItem(key, JSON.stringify(settings));
}

export async function getPurchaseInvoices(businessId: string): Promise<PurchaseInvoice[]> { return getBusinessData(businessId, config.BASE_PURCHASE_INVOICES_STORAGE_KEY, 'purchaseInvoices'); }
export async function savePurchaseInvoices(businessId: string, invoices: PurchaseInvoice[]): Promise<void> { await saveBusinessData(businessId, config.BASE_PURCHASE_INVOICES_STORAGE_KEY, invoices); }

export async function getReturnPurchaseInvoices(businessId: string): Promise<ReturnPurchaseInvoice[]> { return getBusinessData(businessId, config.BASE_RETURN_PURCHASE_INVOICES_STORAGE_KEY, 'returnPurchaseInvoices'); }
export async function saveReturnPurchaseInvoices(businessId: string, invoices: ReturnPurchaseInvoice[]): Promise<void> { await saveBusinessData(businessId, config.BASE_RETURN_PURCHASE_INVOICES_STORAGE_KEY, invoices); }

export async function getSalesReturnInvoices(businessId: string): Promise<SalesReturnInvoice[]> { return getBusinessData(businessId, config.BASE_SALES_RETURN_INVOICES_STORAGE_KEY, 'salesReturnInvoices'); }
export async function saveSalesReturnInvoices(businessId: string, invoices: SalesReturnInvoice[]): Promise<void> { await saveBusinessData(businessId, config.BASE_SALES_RETURN_INVOICES_STORAGE_KEY, invoices); }

export async function getOutgoingPayments(businessId: string): Promise<OutgoingPayment[]> { return getBusinessData(businessId, config.BASE_OUTGOING_PAYMENTS_STORAGE_KEY, 'outgoingPayments'); }
export async function saveOutgoingPayments(businessId: string, payments: OutgoingPayment[]): Promise<void> { await saveBusinessData(businessId, config.BASE_OUTGOING_PAYMENTS_STORAGE_KEY, payments); }

export async function getIncomingPayments(businessId: string): Promise<IncomingPayment[]> { return getBusinessData(businessId, config.BASE_INCOMING_PAYMENTS_STORAGE_KEY, 'incomingPayments'); }
export async function saveIncomingPayments(businessId: string, payments: IncomingPayment[]): Promise<void> { await saveBusinessData(businessId, config.BASE_INCOMING_PAYMENTS_STORAGE_KEY, payments); }

export async function getLocalSalesInvoices(businessId: string): Promise<LocalSaleInvoice[]> { return getBusinessData(businessId, config.BASE_LOCAL_SALES_INVOICES_STORAGE_KEY, 'localSalesInvoices'); }
export async function saveLocalSalesInvoices(businessId: string, invoices: LocalSaleInvoice[]): Promise<void> { await saveBusinessData(businessId, config.BASE_LOCAL_SALES_INVOICES_STORAGE_KEY, invoices); }

export async function getCreditNotes(businessId: string): Promise<CreditNote[]> { return getBusinessData(businessId, config.BASE_CREDIT_NOTES_STORAGE_KEY, 'creditNotes'); }
export async function saveCreditNotes(businessId: string, notes: CreditNote[]): Promise<void> { await saveBusinessData(businessId, config.BASE_CREDIT_NOTES_STORAGE_KEY, notes); }

export async function getDebitNotes(businessId: string): Promise<DebitNote[]> { return getBusinessData(businessId, config.BASE_DEBIT_NOTES_STORAGE_KEY, 'debitNotes'); }
export async function saveDebitNotes(businessId: string, notes: DebitNote[]): Promise<void> { await saveBusinessData(businessId, config.BASE_DEBIT_NOTES_STORAGE_KEY, notes); }

export async function getRecipes(businessId: string): Promise<Recipe[]> { return getBusinessData(businessId, config.BASE_RECIPES_STORAGE_KEY, 'recipes'); }
export async function saveRecipes(businessId: string, recipes: Recipe[]): Promise<void> { await saveBusinessData(businessId, config.BASE_RECIPES_STORAGE_KEY, recipes); }

export async function getProductionOrders(businessId: string): Promise<ProductionOrder[]> { return getBusinessData(businessId, config.BASE_PRODUCTION_ORDERS_STORAGE_KEY, 'productionOrders'); }
export async function saveProductionOrders(businessId: string, orders: ProductionOrder[]): Promise<void> { await saveBusinessData(businessId, config.BASE_PRODUCTION_ORDERS_STORAGE_KEY, orders); }

export async function getProductionStages(businessId: string): Promise<ProductionStage[]> { return getBusinessData(businessId, config.BASE_PRODUCTION_STAGES_STORAGE_KEY, 'productionStages'); }
export async function saveProductionStages(businessId: string, stages: ProductionStage[]): Promise<void> { await saveBusinessData(businessId, config.BASE_PRODUCTION_STAGES_STORAGE_KEY, stages); }

export async function getProductionRoutings(businessId: string): Promise<ProductionRouting[]> { return getBusinessData(businessId, config.BASE_PRODUCTION_ROUTINGS_STORAGE_KEY, 'productionRoutings'); }
export async function saveProductionRoutings(businessId: string, routings: ProductionRouting[]): Promise<void> { await saveBusinessData(businessId, config.BASE_PRODUCTION_ROUTINGS_STORAGE_KEY, routings); }

// Session Storage
export function getCurrentUserIdFromSessionStorage(): string | null {
    return sessionStorage.getItem(config.CURRENT_USER_ID_SESSION_KEY);
}

export function saveCurrentUserIdToSessionStorage(userId: string | null): void {
    if (userId) {
        sessionStorage.setItem(config.CURRENT_USER_ID_SESSION_KEY, userId);
    } else {
        sessionStorage.removeItem(config.CURRENT_USER_ID_SESSION_KEY);
    }
}

export function getCurrentManagingBusinessIdFromSessionStorage(): string | null {
    return sessionStorage.getItem(config.CURRENT_MANAGING_BUSINESS_ID_SESSION_KEY);
}

export function saveCurrentManagingBusinessIdToSessionStorage(businessId: string | null): void {
    if (businessId) {
        sessionStorage.setItem(config.CURRENT_MANAGING_BUSINESS_ID_SESSION_KEY, businessId);
    } else {
        sessionStorage.removeItem(config.CURRENT_MANAGING_BUSINESS_ID_SESSION_KEY);
    }
}